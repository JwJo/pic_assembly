//-------------------------------------------------------------------------------//                                                                                                                           
//                            LIXUE ���ӹ�����                                   //
//                       http://lixuediy.taobao.com                              // 
//                                ��Ȩ����                                       //
//                       EMAIL:lixue51@126.com                                   //
//                       Mobile:13109884800                                      //
//                       MCU: PIC16F1937                                         //
//                       Compiler: PIC10/12/16 MCUs V9.80                        //
//                       File: LX-PWM.c                                          //
//                       DATE: 2010-11-04    Version:  1.0                       //                                    
//-------------------------------------------------------------------------------//
#include "pic.h"

__CONFIG(FOSC_INTOSC&CLKOUTEN_OFF&MCLRE_ON&WDTE_OFF);//&PWRTE_ON&BOREN_ON

#define _XTAL_FREQ      4000000L            //�ڲ�4MHz

static bit TickClock  = 0;                  //2.5mS ʱ��

//---------------------------------------------------------------

//*******************************************************************//
//                          ϵͳ��ʼ��
//*******************************************************************//
void System_Init(void)
{
	OSCCON = 0b01101000;            //�ڲ�4MHz 
	OSCTUNE= 0b00000000;            //����У׼
	ADCON1 = 0b10110000;            //�ڲ�Frc Vref = VDD
	ADCON0 = 0b00010001;            //ADON = 1 As AN4
    
	TRISA  = 0b00100000;            //RA0-RA3�����RA5����
	ANSELA = 0b00100000;            //RA5 ģ������  
	          
	TRISB  = 0b00001111;            //RB0-RB3��������
	ANSELB = 0b00001111;            //4����������
	WPUB   = 0b00000000;            //������
    
	IOCBP  = 0b00000000;            //�ص�ƽ�仯�ж�
	IOCBN  = 0b00000000;
	
	TRISD  = 0b00000000;            //PORTD���
	ANSELD = 0b00000000;            //����  I/O
    
	TRISC  = 0b10011000;            //���� I2C
    
	TRISE  = 0b00000000;            //PORTE���
	ANSELE = 0b00000000;            //����  I/O
	WPUE   = 0b00000000;            //������ 
	
	LATA  = 0x00;
	LATB  = 0x00;
	LATC  = 0x00;
	LATD  = 0x00;
	LATE  = 0x00;
}
void CCP1_Init(void)
{
	CCP1CON = 0b00001100;         //CCP1 ΪPWMģʽ 
	CCPTMRS0= 0b00000000;         //CCP1 ʱ����ԴTMR2
	CCPTMRS1= 0b00000000;
	CCP1IE = 0;
	CCP1IF = 0;
	
	T2CON = 0b01001100;           // Postcaler 1:10, T2ON
	PR2 = 249;                    // PWM���� = (PR2+1)*4*TOSC
	                              // TOSC = 1/FOSC
	CCPR1L = 0x00;                // ռ�ձ� 0
	
	TMR2IF = 0;
	TMR2IE = 0;
}	

//*******************************************************************//
//                       TMR0��ʱ2.5mS
//*******************************************************************//
void TMR0_Init(void)
{
	OPTION_REG = 0b11010011;
	
	TMR0IF = 0;
	TMR0IE = 1;
}

//*******************************************************************//
//                    ��ʱ���ж�,��ʱ��������
//*******************************************************************//  

static void interrupt SystemISR(void)      //ϵͳ�ж�
{
	if(TMR0IE && TMR0IF)                   //4MHz  2.5ms
	{
		TMR0IF = 0;
		TMR0 = 0x65;
		CLRWDT();
		TickClock = 1;
	}		
}
//--------------------------------------------------------------------
unsigned int PWM_Duty = 0;      //PWM ռ�ձ�
static bit PWM_FLAG  = 0;       //�����־λ
void Conver_CCPR1L(void)        //PWM ռ�ձ�ת��
{
	CCPR1L = (unsigned char)(PWM_Duty>>2);
	CCP1CON |= (unsigned char)((PWM_Duty&0x0003)<<4);
}
void PWM_LED(void)
{   
	if (TickClock)              //2.5mS
	{
		TickClock = 0;
		if(PWM_FLAG == 1)       //PWM LED  ����    
		{
			if(PWM_Duty != 0)   PWM_Duty --;
			else                PWM_FLAG = 0;
		}
		else                    //PWM LED  ����
		{
			if(PWM_Duty <1023)  PWM_Duty++;
			else                PWM_FLAG = 1;		
		}
		Conver_CCPR1L();		   
	}
}
		


//*******************************************************************//
//                             �����򲿷�
//*******************************************************************//

void main(void)
{
	__delay_ms(50);
	System_Init();          //ϵͳ��ʼ��
	CLRWDT();               //WDT �Ź�
	CCP1_Init();            //CCP1��ʼ��
	TMR0_Init();            //TMR0��ʼ��
	PEIE = 1;               //�����ж�����
	GIE = 1;                //���ж�����
	while(1)
	{
		PWM_LED();
		__delay_ms(5);	
	}
}

