//-------------------------------------------------------------------------------//                                                                                                                           
//                            LIXUE ���ӹ�����                                   //
//                       http://lixuediy.taobao.com                              // 
//                                ��Ȩ����                                       //
//                       EMAIL:lixue51@126.com                                   //
//                       Mobile:13109884800                                      //
//                       MCU: PIC16F1937                                         //
//                       Compiler: PIC10/12/16 MCUs V9.80                        //
//                       File: LX-TMR1.c                                          //
//                       DATE: 2010-11-04    Version:  1.0                       //                                    
//-------------------------------------------------------------------------------//
#include "pic.h"

__CONFIG(FOSC_INTOSC&CLKOUTEN_OFF&MCLRE_ON&WDTE_OFF);//&PWRTE_ON&BOREN_ON

#define _XTAL_FREQ      4000000L            //�ڲ�4MHz

#define TMR1HPRELOAD    0x3C
#define TMR1LPRELOAD    0xBE

//*******************************************************************//
//                          ϵͳ��ʼ��
//*******************************************************************//
void System_Init(void)
{
	OSCCON = 0b01101000;            //�ڲ�4MHz 
	OSCTUNE= 0b00000000;            //����У׼
	ADCON1 = 0b10110000;            //�ڲ�Frc Vref = VDD
	ADCON0 = 0b00010001;            //ADON = 1 As AN4
    
	TRISA  = 0b00100000;            //RA0-RA3�����RA5����
	ANSELA = 0b00100000;            //RA5 ģ������  
	          
	TRISB  = 0b00001111;            //RB0-RB3��������
	ANSELB = 0b00001111;            //4����������
	WPUB   = 0b00000000;            //������
    
	IOCBP  = 0b00000000;            //�ص�ƽ�仯�ж�
	IOCBN  = 0b00000000;
	
	TRISD  = 0b00000000;            //PORTD���
	ANSELD = 0b00000000;            //����  I/O
    
	TRISC  = 0b10011000;            //���� I2C
    
	TRISE  = 0b00000000;            //PORTE���
	ANSELE = 0b00000000;            //����  I/O
	WPUE   = 0b00000000;            //������ 
	
	LATA  = 0x00;
	LATB  = 0x00;
	LATC  = 0x00;
	LATD  = 0x00;
	LATE  = 0x00;
}
	

//*******************************************************************//
//                       TMR1��ʱ����ʼ��
//*******************************************************************//
void TMR1_Init(void)
{	
	TMR1CS0 = 0;             //System Timer1 Initialize
	TMR1CS1 = 0;             
	TMR1H = TMR1HPRELOAD;
	TMR1L = TMR1LPRELOAD;
	TMR1IF = 0;
	TMR1IE = 1;
}

//*******************************************************************//
//                    ��ʱ���ж�,��ʱ��������
//*******************************************************************//  

static void interrupt SystemISR(void)      //ϵͳ�ж�
{
	if(TMR1IE && TMR1IF)                   //4MHz   50mS
	{
		TMR1IF = 0;
		TMR1H = TMR1HPRELOAD;
		TMR1L = TMR1LPRELOAD;
		CLRWDT();
		LATA1 = ~LATA1;                    //TMR1 �жϺ󣬷�תDS2
	}		
}

//*******************************************************************//
//                             �����򲿷�
//*******************************************************************//

void main(void)
{
	__delay_ms(50);
	System_Init();          //ϵͳ��ʼ��
	CLRWDT();               //WDT ���Ź�
	TMR1_Init();            //TMR1��ʼ��
	PEIE = 1;               //�����ж�����
	GIE = 1;                //���ж�����
	TMR1ON = 1;             //����TMR1��ʱ
	while(1)
	{
		LATC2 = 1;          //ϵͳ�źŵ� PWM LED
		__delay_ms(50);
		LATC2 = 0;
		__delay_ms(1500);	
	}
}

