//-------------------------------------------------------------------------------//                                                                                                                           
//                            LIXUE ���ӹ�����                                   //
//                       http://lixuediy.taobao.com                              // 
//                                ��Ȩ����                                       //
//                       EMAIL:lixue51@126.com                                   //
//                       Mobile:13109884800                                      //
//                       MCU: PIC16F1937                                         //
//                       Compiler: PIC10/12/16 MCUs V9.80                        //
//                       File: LX-mTouch.c                                       //
//                       DATE: 2011-02-23    Version:  1.0                       //                                    
//-------------------------------------------------------------------------------//
#include "user.h"

__CONFIG(FOSC_INTOSC&CLKOUTEN_OFF&MCLRE_ON&PWRTE_ON&BOREN_ON&CP_ON&CPD_ON);//&WDTE_OFF);


__EEPROM_DATA(0x01,0x6E,0x6E,0x6E,0x6E,0x0B,0x65,0xFF);      //�ڲ�EEPROM��ֵ


#define _XTAL_FREQ      4000000L            //�ڲ�4MHz



static bit Key1_FLAG  = 0;                  //����������־λ 
static bit Key2_FLAG  = 0;
static bit Key3_FLAG  = 0;
static bit Key4_FLAG  = 0;

static bit Key1_Touch = 0;                  //������Ч��־λ
static bit Key2_Touch = 0;
static bit Key3_Touch = 0;
static bit Key4_Touch = 0;

unsigned char Key1_Count = 0;               //������������
unsigned char Key2_Count = 0;
unsigned char Key3_Count = 0;
unsigned char Key4_Count = 0;
unsigned char Key_Sensor = 10;              //����������

unsigned char Tick_10mS  = 0;               // ϵͳʱ��
unsigned char Tick_500mS = 0;

//---------------------------------------------------------------

//*******************************************************************//
//                          ϵͳ��ʼ��
//*******************************************************************//
void System_Init(void)
{
	OSCCON = 0b01101000;            //�ڲ�4MHz 
	OSCTUNE= 0b00000000;            //����У׼
	ADCON1 = 0b10110000;            //�ڲ�Frc Vref = VDD
	ADCON0 = 0b00010001;            //ADON = 1 As AN4
    
	TRISA  = 0b00100000;            //RA0-RA3�����RA5����
	ANSELA = 0b00100000;            //RA5 ģ������  
	          
	TRISB  = 0b00001111;            //RB0-RB3��������
	ANSELB = 0b00001111;            //4����������
	WPUB   = 0b00000000;            //������
    
	IOCBP  = 0b00000000;            //�ص�ƽ�仯�ж�
	IOCBN  = 0b00000000;
	
	TRISD  = 0b00000000;            //PORTD���
	ANSELD = 0b00000000;            //����  I/O
    
	TRISC  = 0b10011000;            //���� I2C
    
	TRISE  = 0b00000000;            //PORTE���
	ANSELE = 0b00000000;            //����  I/O
	WPUE   = 0b00000000;            //������ 
	
	LATA  = 0x00;
	LATB  = 0x00;
	LATC  = 0x00;
	LATD  = 0x00;
	LATE  = 0x00;
}
//*******************************************************************//
//                          ���ڳ�ʼ��
//*******************************************************************//
void RS232_Init(void)              //Init For Modbus
{
	idelslotlong = IDELSLOTLONG - 3;
	SPBRG = 25;           // 9600 N 8 1
	BRGH = 1;             // Fast Buad rate
	SYNC = 0;	          // asynchronous
	SPEN = 1;	          // enable serial port pins
	CREN = 1;	          // enable reception
	TXEN = 1;             // enable Send
	SREN = 0;	          // No effect
	TXIE = 0;             // Disable TX interrupts
	RCIE = 1;             // Enable  RX interrupts
}
//*******************************************************************//
//                          �ڲ�EEPROM ��
//*******************************************************************//
unsigned char EE_readbyte(unsigned char EEAddr)
{
	EEADR = EEAddr;       //д���ַ          
	EEPGD = 0;            //����EEPROM�洢��
	RD = 1;
	return EEDATA;
}
//*******************************************************************//
//                          �ڲ�EEPROM д
//*******************************************************************//	
void EE_writebyte(unsigned char EEAddr,unsigned char EEdata)
{  
	asm("CLRWDT");
	while(WR);
	EEADR  = EEAddr;      //д���ַ
	EEDATA = EEdata;      //д������
	EEPGD = 0;            //����EEPROM�洢��
	WREN = 1;             //��������
	GIE = 0;              //���ж�
	EECON2 = 0x55;        //д����Կ
	EECON2 = 0xaa;
	WR = 1;               //��ʼд����
	asm("nop");
	asm("nop");
	GIE = 1;
	WREN = 0;
	while(WR);
}	
//*******************************************************************//
//                    ���������Ĵ�����ʼ��
//                    ʹ��TMR0��ʱ2.5mS,��ѰTMR1 ����ֵ
//*******************************************************************//
void Cap_Init(void)
{
	CPSCON0 = 0b10001100;         //�򿪵���ģ�飬��Ƶ����
	CPSCON1 = 0b00000011;         //����ɨ��ͨ�� 3-5  8-15
	
	OPTION_REG = 0b11010011;
	
	TMR0IF = 0;
	TMR0IE = 1;
	
	T1CON  = 0b11000101;          //����,ʱ����Դ����ģ�� 1:1��Ƶ
	T1GCON = 0b00000000;          //���ſ�λ�޹�
	TMR1GIF = 0;
	TMR1GIE = 0;
}

//*******************************************************************//
//                    �л���������ͨ��
//*******************************************************************//
unsigned char Index	= 0;            // ������ͨ������
void SetNextSensor(void)
{
	if(Index == 3)  Index = 0;      //KEY1 --- KEY4
	else            Index ++;
	CPSCON1 = Index;
}	
//*******************************************************************//
//                    �������� TMR1 ����
//*******************************************************************// 
void RestartTimers(void)
{
	TMR1ON = 0;                                  //ReStart Timer1
	TMR1H  = 0;
	TMR1L  = 0;
	TMR1ON = 1; 	
}

unsigned char AvgIndex = 0;                      //����Ƶ�ʼ���
unsigned int  Cap_Value = 0;                     //��ǰ����Ƶ��ֵ
unsigned int trip[4]= {110,110,110,110};         //Ƶ�ʲ�ֵ
unsigned int Cap_Avg[4] ={600,600,600,600};      //Ƶ��ƽ��ֵ
unsigned int KEY_Avg[4] ={0,0,0,0};              //��ǰƵ��ֵ��
//*******************************************************************//
//                    ��������Ƶ�ʷ������
//*******************************************************************//  
void Cap_ISR(void) 
{
	KEY_Avg[Index] = Cap_Value;
	if (Cap_Value < (Cap_Avg[Index] - trip[Index]))    //�м�����,������Ƶ��ƽ��ֵ
	{
		switch(Index) 
		{
			case 0: Key1_FLAG  = 1; LATA0 = 1;break;   //CSM 0  KEY1 
			case 1: Key2_FLAG  = 1; LATA1 = 1;break;   //CSM 1  KEY2 
			case 2: Key3_FLAG  = 1; LATA2 = 1;break;   //CSM 2  KEY3 
			case 3: Key4_FLAG  = 1; LATA3 = 1;break;   //CSM 3  KEY4 
			default : break;
		}
	} 
	//else if (Cap_Value > (Cap_Avg[Index] - trip[Index] +64)) //�޼�����,������Ƶ��ƽ��ֵ
	if (Cap_Value > (Cap_Avg[Index] - trip[Index] +32)) //�޼�����,������Ƶ��ƽ��ֵ
	{
		switch(Index) 
		{
			case 0: Key1_FLAG  = 0; LATA0 = 0;break;   //CSM 0  KEY1 
			case 1: Key2_FLAG  = 0; LATA1 = 0;break;   //CSM 1  KEY2   
			case 2: Key3_FLAG  = 0; LATA2 = 0;break;   //CSM 2  KEY3  
			case 3: Key4_FLAG  = 0; LATA3 = 0;break;   //CSM 3  KEY4  

			default : break;
		}
		if (AvgIndex < 2)       AvgIndex ++;           //����Ƶ��
		else                    AvgIndex = 0;
		if (AvgIndex == 2)
		{
			if(Cap_Value >= Cap_Avg[Index])
				Cap_Avg[Index] = Cap_Avg[Index]+(Cap_Value - Cap_Avg[Index])/8;
			else 
				Cap_Avg[Index] = Cap_Avg[Index]-(Cap_Avg[Index] - Cap_Value)/8;
		}
	}
}
	
//*******************************************************************//
//                    ��ʱ���ж�,��ʱ��������
//*******************************************************************//  
unsigned char TMR0_LOAD = 0;               //��ʱ��0��ֵ
static void interrupt SystemISR(void)      //ϵͳ�ж�
{
	if(TMR0IE && TMR0IF)                   //4MHz  2.5ms
	{
		TMR1ON = 0;                        //ֹͣ����������Ƶ�ʼ���
		TMR0IF = 0;
		TMR0 = TMR0_LOAD;
		
		Tick_10mS ++;                      //ϵͳʱ��
		
		if (IdelSlot != 0)   IdelSlot--;   //ModBus������
		Cap_Value = (unsigned int)(TMR1H <<8) + TMR1L;	//��ȡ��Ƶ��

		Cap_ISR();		           
		SetNextSensor();
		RestartTimers();
		
		CLRWDT();
	}
	if(RCIF & RCIE)                        //�����ж�
	{
		if (RCSTAbits.FERR)
		{
			RCSTAbits.CREN = 0;
			RCSTAbits.CREN = 1;
		}
		if (IdelSlot == 0)
		{
			bReceivedHead = 1;
			ModBusRecvBufferCount = 0;
		}
		ModbusRecvBuffer[ModBusRecvBufferCount] = RCREG;
		IdelSlot = idelslotlong;
		ModBusRecvBufferCount = (ModBusRecvBufferCount + 1) & 0x0F;
		if (RCSTAbits.OERR)
		{
			ModbusRecvBuffer[ModBusRecvBufferCount] = RCREG;
			IdelSlot = idelslotlong;
			ModBusRecvBufferCount = (ModBusRecvBufferCount + 1) & 0x0F;
			RCSTAbits.CREN = 0;
			RCSTAbits.CREN = 1;
		}
	}
	if(TXIF & TXIE)                        //�����ж�
	{  
		if ( ModBusSendBufferCount != ModBusSendBufferNum)
		{
			TXREG = ModbusSendBuffer[ModBusSendBufferCount];
			ModBusSendBufferCount++;
			bReceivedHead = 0;
			ModBusRecvBufferCount = 0;
			IdelSlot = idelslotlong;
		}
		else
		{ 
			if (TXSTAbits.TRMT)
			{  
				PIE1bits.TXIE = 0;       //ֹͣ����
				PIE1bits.RCIE = 1;       //��������
			}
		}
	}
	if (TMR0IE && TMR0IF) 
	{
		TMR0IF = 0;
		RestartTimers();
	}		
}
//*******************************************************************//
//                          ����ɨ��
//*******************************************************************//
void key1_scan(void)                //KEY1������ 
{
	if (!Key1_FLAG)
	{
		Key1_Count = 0; 
		Key1_Touch = 0;         
	}
	else
	{ 
		if(!Key1_Touch)
		{
			if (Key1_Count > Key_Sensor)
			{
				ModBusSendBufferNum = 6;                          // ����n������
				ModbusSendBuffer[0] = EE_readbyte(EE_SET_Addr);   // ��������ַ
				ModbusSendBuffer[1] = 0x03;                       // ����ֵ����
				ModbusSendBuffer[2] = 0x00;
				ModbusSendBuffer[3] = 0x01;                       // �����Ĵ���
				ModbusSendBuffer[4] = 0x00;
				ModbusSendBuffer[5] = 0x01;                       // ����ֵ
				SendModBusCommand(6);                             // ��������
				Key1_Touch = 1;        
			}
			else 	Key1_Count++; 	
		}		
	}	
}  	

void key2_scan(void)                //KEY2������ 
{
	if (!Key2_FLAG)
	{
		Key2_Count = 0; 
		Key2_Touch = 0;         
	}
	else
	{ 
		if(!Key2_Touch)
		{
			if (Key2_Count > Key_Sensor)
			{
				ModBusSendBufferNum = 6;                          // ����n������
				ModbusSendBuffer[0] = EE_readbyte(EE_SET_Addr);   // ��������ַ
				ModbusSendBuffer[1] = 0x03;                       // ����ֵ����
				ModbusSendBuffer[2] = 0x00;
				ModbusSendBuffer[3] = 0x02;                       // �����Ĵ���
				ModbusSendBuffer[4] = 0x00;
				ModbusSendBuffer[5] = 0x02;                       // ����ֵ
				SendModBusCommand(6);                             // �������� 
				Key2_Touch = 1;        
			}
			else 	Key2_Count++; 	
		}		
	}	
} 
void key3_scan(void)                //KEY3������ 
{
	if (!Key3_FLAG)
	{
		Key3_Count = 0; 
		Key3_Touch = 0;         
	}
	else
	{ 
		if(!Key3_Touch)
		{
			if (Key3_Count > Key_Sensor)
			{
				ModBusSendBufferNum = 6;                          // ����n������
				ModbusSendBuffer[0] = EE_readbyte(EE_SET_Addr);   // ��������ַ
				ModbusSendBuffer[1] = 0x03;                       // ����ֵ����
				ModbusSendBuffer[2] = 0x00;
				ModbusSendBuffer[3] = 0x03;                       // �����Ĵ���
				ModbusSendBuffer[4] = 0x00;
				ModbusSendBuffer[5] = 0x03;                       // ����ֵ
				SendModBusCommand(6);                             // �������� 
				Key3_Touch = 1;        
			}
			else 	Key3_Count++; 	
		}		
	}	
} 
void key4_scan(void)                //KEY4������ 
{
	if (!Key4_FLAG)
	{
		Key4_Count = 0; 
		Key4_Touch = 0;         
	}
	else
	{ 
		if(!Key4_Touch)
		{
			if (Key4_Count > Key_Sensor)
			{
				ModBusSendBufferNum = 6;                          // ����n������
				ModbusSendBuffer[0] = EE_readbyte(EE_SET_Addr);   // ��������ַ
				ModbusSendBuffer[1] = 0x03;                       // ����ֵ����
				ModbusSendBuffer[2] = 0x00;
				ModbusSendBuffer[3] = 0x04;                       // �����Ĵ���
				ModbusSendBuffer[4] = 0x00;
				ModbusSendBuffer[5] = 0x04;                       // ����ֵ
				SendModBusCommand(6);                             // ��������
				Key4_Touch = 1;        
			}
			else 	Key4_Count++; 	
		}		
	}	
} 
	
//*******************************************************************//
//                          ͨ�Ŵ���
//*******************************************************************//	
void DoCommEvents(void)
{
	unsigned char ComLong;
	unsigned char Temp;
	if ((IdelSlot == 0) && (bReceivedHead))   //Have Received a Command
	{
		Temp = 0;
		if (ModBusRecvBufferCount > 7) 
		{
			bReceivedHead = 0;
			PIE1bits.RCIE = 0;
			if ( (ModbusRecvBuffer[0] == 254)|| (ModbusRecvBuffer[0] == 255)||(ModbusRecvBuffer[0] == EE_readbyte(EE_SET_Addr))) 
			{
				GenCRC16(ModbusRecvBuffer,ModBusRecvBufferCount - 2);
				if ((ModbusRecvBuffer[ModBusRecvBufferCount - 2] == uchCRCLo) && (ModbusRecvBuffer[ModBusRecvBufferCount - 1] == uchCRCHi))
				{
					Temp = 1;
					ModbusSendBuffer[0] = ModbusRecvBuffer[0];
					ModbusSendBuffer[1] = ModbusRecvBuffer[1];
					ModbusSendBuffer[2] = ModbusRecvBuffer[2];
					ModbusSendBuffer[3] = ModbusRecvBuffer[3];
					ModbusSendBuffer[4] = ModbusRecvBuffer[4];
					ModbusSendBuffer[5] = ModbusRecvBuffer[5];
					ModbusSendBuffer[6] = ModbusRecvBuffer[6];
					ModbusSendBuffer[7] = ModbusRecvBuffer[7];
					ModBusSendBufferNum = ModBusRecvBufferCount;
				}
				if (Temp != 0) 
				{
					switch (ModbusRecvBuffer[1])
					{
						case MODBUS_WRITE_REGISTER_DATA:
										ComLong = 6;
										ModBusSendBufferNum = 6;
										switch(ModbusRecvBuffer[3])
										{
											case EE_SET_Addr: 
													EE_writebyte (EE_SET_Addr,ModbusRecvBuffer[5]);
													ModbusSendBuffer[5] = EE_readbyte(EE_SET_Addr);
													break;
											case EE_Key1_Trip: 
													EE_writebyte (EE_Key1_Trip,ModbusRecvBuffer[5]);
													ModbusSendBuffer[5] = EE_readbyte(EE_Key1_Trip);
													trip[0] = ModbusSendBuffer[5];      // ���·�ֵ1
													break;
											case EE_Key2_Trip: 
													EE_writebyte (EE_Key2_Trip,ModbusRecvBuffer[5]);
													ModbusSendBuffer[5] = EE_readbyte(EE_Key2_Trip);
													trip[1] = ModbusSendBuffer[5];      // ���·�ֵ2
													break;
											case EE_Key3_Trip: 
													EE_writebyte (EE_Key3_Trip,ModbusRecvBuffer[5]);
													ModbusSendBuffer[5] = EE_readbyte(EE_Key3_Trip);
													trip[2] = ModbusSendBuffer[5];      // ���·�ֵ3
													break;
											case EE_Key4_Trip: 
													EE_writebyte (EE_Key4_Trip,ModbusRecvBuffer[5]);
													ModbusSendBuffer[5] = EE_readbyte(EE_Key4_Trip);
													trip[3] = ModbusSendBuffer[5];      // ���·�ֵ4
													break;
											case EE_Key_Sensor:
													EE_writebyte (EE_Key_Sensor,ModbusRecvBuffer[5]);
													ModbusSendBuffer[5] = EE_readbyte(EE_Key_Sensor);
													Key_Sensor = ModbusSendBuffer[5];   // ���´���������
													break;
											case EE_TMR0_LOAD:
													EE_writebyte (EE_TMR0_LOAD,ModbusRecvBuffer[5]);
													ModbusSendBuffer[5] = EE_readbyte(EE_TMR0_LOAD);
													TMR0_LOAD = ModbusSendBuffer[5];    // ���¶�ʱ0ֵ
													break;
											default:    ComLong =  3;
														ModBusSendBufferNum = 3;
														ModbusSendBuffer[1] = ModbusSendBuffer[1] | 0x80; 
														ModbusSendBuffer[2] = 0x02;     //�Ƿ����ݵ�ַ
														break;																							
										}
										break;

						default:   
										ComLong =  3;
										ModBusSendBufferNum = 3;
										ModbusSendBuffer[1] = ModbusSendBuffer[1] | 0x80; 
										ModbusSendBuffer[2] = 0x01;       //�Ƿ����ܴ���
										break;
					} 
					if (ModbusRecvBuffer[0] != 0xff) SendModBusCommand(ComLong);
				}	
			}
			else
			{
				bReceivedHead = 0;
				PIE1bits.RCIE = 1;
			}
		}
	}
}
//*******************************************************************//
//                           ������ʼ��
//*******************************************************************//
void VarInitialize(void)
{
	trip[0] = EE_readbyte(0x01);         //��ȡ����������ֵ
	trip[1] = EE_readbyte(0x02);
	trip[2] = EE_readbyte(0x03);
	trip[3] = EE_readbyte(0x04);
	Key_Sensor = EE_readbyte(0x05);      //��ȡ��������������
	
	TMR0_LOAD = EE_readbyte(0x06);       //��ȡ��ʱ��0��ֵ
	
	ModBusSendBufferNum = 6;
	ModbusSendBuffer[0] = EE_readbyte(EE_SET_Addr);   //������ַ
	
}		
//*******************************************************************//
//                             �����򲿷�
//*******************************************************************//

void main(void)
{
	__delay_ms(100);        // ��ʱ��ʱ
	System_Init();          // ϵͳ��ʼ��
	RS232_Init();           // ���ڳ�ʼ��
	CLRWDT();               // WDT �Ź�
	Cap_Init();             // CSM ��ʼ��
	VarInitialize();        // ϵͳ������ʼ��
		
	PEIE = 1;               // �����ж�����
	GIE = 1;                // ���ж�����
	do
	{
		DoCommEvents();
		CLRWDT();
		if(Tick_10mS > 3)
		{
			Tick_10mS = 0;
			Tick_500mS++;
			key1_scan();
			key2_scan();
			key3_scan();
			key4_scan();
		}	
		if(Tick_500mS > 49)
		{
			Tick_500mS = 0;
			LATC2 = !LATC2;
		}	
	}while (1);
}

