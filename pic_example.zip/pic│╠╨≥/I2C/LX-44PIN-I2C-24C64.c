//-------------------------------------------------------------------------------//
//                            LIXUE ���ӹ�����                                   //
//                       http://lixuediy.taobao.com                              //
//                                ��Ȩ����                                       //
//                       EMAIL:lixue51@126.com                                   //
//                       Mobile:13109884800                                      //
//                       MCU: PIC16F1937                                         //
//                       Compiler: PIC10/12/16 MCUs V9.80                        //
//                       File: LX-I2C-24C64.C                                    //
//                       DATE: 2010-11-12    Version:  1.0                       //
//-------------------------------------------------------------------------------//
#include "pic.h"

__CONFIG(FOSC_INTOSC&CLKOUTEN_OFF&MCLRE_ON&LVP_OFF&WDTE_OFF);//&PWRTE_ON&BOREN_ON

#define _XTAL_FREQ      4000000L            // �ڲ�4MHz



#define CMD0            0xA0                // д����
#define CMD1            0xA1                // ������
#define Page_Length	    4                   // ҳ��С

unsigned char I2C_Write_Buffer[Page_Length];// д����
unsigned char I2C_Read_Buffer [Page_Length];// ������
//*******************************************************************//
//                          ϵͳ��ʼ��
//*******************************************************************//
void System_Init(void)
{
	OSCCON = 0b01101000;            //�ڲ�4MHz 
	OSCTUNE= 0b00000000;            //����У׼
	ADCON1 = 0b10110000;            //�ڲ�Frc Vref = VDD
	ADCON0 = 0b00010001;            //ADON = 1 As AN4
    
	TRISA  = 0b00100000;            //RA0-RA3�����RA5����
	ANSELA = 0b00100000;            //RA5 ģ������  
	          
	TRISB  = 0b00001111;            //RB0-RB3��������
	ANSELB = 0b00001111;            //4����������
	WPUB   = 0b00000000;            //������
    
	IOCBP  = 0b00000000;            //�ص�ƽ�仯�ж�
	IOCBN  = 0b00000000;
	
	TRISD  = 0b00000000;            //PORTD���
	ANSELD = 0b00000000;            //����  I/O
    
	TRISC  = 0b10011000;            //���� I2C
    
	TRISE  = 0b00000000;            //PORTE���
	ANSELE = 0b00000000;            //����  I/O
	WPUE   = 0b00000000;            //������ 
	
	LATA  = 0x00;
	LATB  = 0x00;
	LATC  = 0x00;
	LATD  = 0x00;
	LATE  = 0x00;
}
//--------------------------------- I2C���� -------------------------------------//
void I2C_Master_Init(void)  // I2C ģ���ʼ��
{
	SSPCON1 = 0b00101000;   // SSPEN = 1, Master Mode
	SSPCON2 = 0b00000000;   // GCEN = 0
	SSPCON3 = 0b00000000;   //
	SSPMSK  = 0b00000000;   // No Address detect
	SSPADD  = 0b00001001;   // 100KHz @4MHz
}
void IdleI2C(void)          // I2C ���߿��м��
{
	while ((SSPCON2&0x1F) || (SSPSTATbits.R_nW))
	continue;
}
void StartI2C(void)         // I2C ��������
{
	SEN = 1;
}
void RestartI2C(void)       // I2C ������������
{
	RSEN = 1;
}
void StopI2C(void)          // I2C ����ֹͣ
{
	PEN = 1;
}
void AckI2C(void)           // I2C ����Ӧ��
{
	ACKDT = 0;
	ACKEN = 1;
}
void NotAckI2C(void)        // I2C ������Ӧ��
{
	ACKDT = 1;
	ACKEN = 1;
}
void I2C_Done(void)         // I2C �����жϼ��
{
	while(!SSPIF);
	SSPIF = 0;
}
unsigned char ReadI2C(void) // I2C ���߶�����
{
	SSPCON2bits.RCEN = 1;
	while(!SSPSTATbits.BF);
	return SSPBUF;
}
unsigned char WriteI2C(unsigned char WR_DATA) // I2C ����д����
{
	SSPBUF = WR_DATA;       // write 1 byte to SSPBUF
	if(WCOL)  return 0;     // Write failure
	else      return 1;     // Write successful
} 
//----------------------------------- END ---------------------------------------//


//-------------------------------------------------------------------------------//
// �������ƣ� EE_Write_Byte()                                                    //
// ����˵���� EEPROM д1�ֽ�                                                     //
// ��ڲ����� addr : ��ַ                                                        //
//            data : ����                                                        //
// �� �� ֵ:  ��                                                                 //
//-------------------------------------------------------------------------------//
//void EE_Write_Byte( unsigned char addr,unsigned char data )
void EE_Write_Byte( unsigned int addr,unsigned char data )
{
	unsigned char addrH,addrL;
	addrH = (unsigned char)((addr >>8)&0x1F);
	addrL = (unsigned char)(addr);
	IdleI2C();                      // ensure module is idle
  	StartI2C();                     // Start condition
	I2C_Done();                     // Wait Start completed				

	WriteI2C(CMD0);                 // Write Control+Write
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();                     // Clear SSPIF flag

	WriteI2C(addrH);                // Write Address to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();
	
	WriteI2C(addrL);                // Write Address to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();

	WriteI2C(data);                 // Write Data to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();

	StopI2C();                      // Stop condition
	I2C_Done();                     // Wait the Stop completed
}

//-------------------------------------------------------------------------------//
// �������ƣ� EE_SEQU_Write()                                                    //
// ����˵���� EEPROM дn�ֽ�                                                     //
// ��ڲ����� addr  : ��ַ                                                       //
//            length: ����                                                       //
//            *dptr : ָ��                                                       //
// �� �� ֵ:  ��                                                                 //
//-------------------------------------------------------------------------------//
//void EE_SEQU_Write(unsigned char addr,unsigned char length,unsigned char *dptr)
void EE_SEQU_Write(unsigned int addr,unsigned char length,unsigned char *dptr)
{
	unsigned char addrH,addrL;
	addrH = (unsigned char)((addr >>8)&0x1F);
	addrL = (unsigned char)(addr);
	
	IdleI2C();             	        // ensure module is idle
  	StartI2C();                     // Start condition
	I2C_Done();                     // Wait Start condition completed
	
	WriteI2C(CMD0);                 // Write Control+Write to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();                     // Clear SSPIF flag

	WriteI2C(addrH);                // Write Address to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();
	
	WriteI2C(addrL);                // Write Address to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();

	while (length != 0)             // Check write completed ?
	{
		WriteI2C(*dptr);            // Write data to EEPROM
		while(SSPCON2bits.ACKSTAT); // wait Acknowledge from EEPROM
		I2C_Done();	
		dptr++;                     // Point to next byte
		length--;
	}
	
	StopI2C();                      // Stop condition
	I2C_Done();                     // Wait the Stop condition completed
}	

//-------------------------------------------------------------------------------//
// �������ƣ� EE_Read_Byte()                                                     //
// ����˵���� EEPROM ��1�ֽ�                                                     //
// ��ڲ����� addr : ��ַ                                                        //
// �� �� ֵ:  ��                                                                 //
//-------------------------------------------------------------------------------//
//unsigned char EE_Read_Byte(unsigned char addr)
unsigned char EE_Read_Byte(unsigned int addr)
{
	unsigned char f;
	unsigned char addrH,addrL;
	addrH = (unsigned char)((addr >>8)&0x1F);
	addrL = (unsigned char)(addr);
	
	IdleI2C();                      // ensure module is idle
  	StartI2C();                     // Start condition
	I2C_Done();                     // Wait Start condition completed

	WriteI2C(CMD0);                 // Write Control to EEPROM    
	while(SSPCON2bits.ACKSTAT);     // test for ACK condition, if received
	I2C_Done();                     // Clear SSPIF flag

	WriteI2C(addrH);                // Write Address to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();
	
	WriteI2C(addrL);                // Write Address to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();

   	RestartI2C();                   // initiate Restart condition
	I2C_Done();

	WriteI2C(CMD1);                 // Write Control to EEPROM              
	while(SSPCON2bits.ACKSTAT);     // test for ACK condition, if received
	I2C_Done();                     // Clear SSPIF flag

	f=ReadI2C();                    // Enable I2C Receiver & wait BF=1 until received data
	I2C_Done();                     // Clear SSPIF flag

	NotAckI2C();                    // Genarate Non_Acknowledge to EEPROM
	I2C_Done();	   
                     
	StopI2C();                      // send STOP condition
	I2C_Done();                     // wait until stop condition is over 

	return(f);                      // Return Data from EEPROM 
}

//-------------------------------------------------------------------------------//
// �������ƣ� EE_SEQU_Read()                                                     //
// ����˵���� EEPROM ��n�ֽ�                                                     //
// ��ڲ����� addr  : ��ַ                                                       //
//            length: ����                                                       //
//            *dptr : ָ��                                                       //
// �� �� ֵ:  ��                                                                 //
//-------------------------------------------------------------------------------//
//void EE_SEQU_Read(unsigned char addr,unsigned char length,unsigned char *dptr)
void EE_SEQU_Read(unsigned int addr,unsigned char length,unsigned char *dptr)
{
	unsigned char addrH,addrL;
	addrH = (unsigned char)((addr >>8)&0x1F);
	addrL = (unsigned char)(addr);
	
	IdleI2C();                      // ensure module is idle
  	StartI2C();                     // Start condition
	I2C_Done();                     // Wait Start condition completed

	WriteI2C(CMD0);                 // Write Control to EEPROM    
	while(SSPCON2bits.ACKSTAT);     // test for ACK condition, if received
	I2C_Done();                     // Clear SSPIF flag

	WriteI2C(addrH);                // Write Address to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();
	
	WriteI2C(addrL);                // Write Address to EEPROM
	while(SSPCON2bits.ACKSTAT);     // wait Acknowledge from EEPROM
	I2C_Done();                     // Clear SSPIF flag

   	RestartI2C();                   // initiate Restart condition
	I2C_Done();

	WriteI2C(CMD1);                 // Write Control to EEPROM              
	while(SSPCON2bits.ACKSTAT);     // Test for ACK condition, if received
	I2C_Done();                     // Clear SSPIF flag

	while (length!=0)
	{
		*dptr=ReadI2C();            // Store EEPROM data to buffer 
		I2C_Done();	
		dptr++;	
		length--;
				
		if (length == 0) NotAckI2C();
		else             AckI2C();  // send a acknowledge to EEPROM
		
		I2C_Done();
	}

	StopI2C();                      // send STOP condition
	I2C_Done();                     // wait until stop condition is over 
}






void main(void)
{
	unsigned char temp1 = 0;     // ���ֽڶ�д����
	unsigned char temp2 = 0;     // ���ֽڶ�д����
	System_Init();
	I2C_Master_Init();
	EE_Write_Byte(0x0000,0xAC);  // ָ����ַ��д1�ֽ�����
	__delay_ms(20);
	temp1 = EE_Read_Byte(0x0000);// ָ����ַ����1�ֽ�����
	
	
	I2C_Write_Buffer[0] = 0x0A;  // װ�����ֵ
	I2C_Write_Buffer[1] = 0x0B;
	I2C_Write_Buffer[2] = 0x0C;
	I2C_Write_Buffer[3] = 0x0D;
	
	EE_SEQU_Write(0x0001,4,I2C_Write_Buffer); // ָ����ַ��д���ֽ�����
	__delay_ms(20);
	EE_SEQU_Read(0x0001,4,I2C_Read_Buffer);   // ָ����ַ�������ֽ�����
	if((I2C_Write_Buffer[0]==I2C_Read_Buffer[0])&&(I2C_Write_Buffer[1]==I2C_Read_Buffer[1])&&\
		(I2C_Write_Buffer[2]==I2C_Read_Buffer[2])&&(I2C_Write_Buffer[3]==I2C_Read_Buffer[3]))
		temp2 = 1;
	else temp2 = 0;
	while(1)
	{	
		if(temp1 == 0xAC)        // ���ֽڶ�д��ȷ  DS1 ����
		{
			LATA0 = !LATA0;
		}
		else                     // ���ֽڶ�д����  DS2 ����
		{
			LATA0 = 1;
		}
		if(temp2 == 1)           // ���ֽڶ�д��ȷ  DS3 ����
		{
			LATA2 = !LATA2;
		}
		else                     // ���ֽڶ�д����  DS3 ����
		{
			LATA2 = 1;
		}
		__delay_ms(200);		
	}
}
