//-------------------------------------------------------------------------------//
//                            LIXUE ���ӹ�����                                   //
//                       http://lixuediy.taobao.com                              //
//                                ��Ȩ����                                       //
//                       EMAIL:lixue51@126.com                                   //
//                       Mobile:13109884800                                      //
//                       MCU: PIC16F1937                                         //
//                       Compiler: PIC10/12/16 MCUs V9.80                        //
//                       File: LX-UART.c                                         //
//                       DATE: 2010-11-04    Version:  1.0                       //
//-------------------------------------------------------------------------------//
#include "pic.h"

__CONFIG(FOSC_INTOSC&CLKOUTEN_OFF&MCLRE_ON&WDTE_OFF);//&PWRTE_ON&BOREN_ON

#define _XTAL_FREQ      4000000L            //�ڲ�4MHz
#define BAUDRATE        3                   //���岨���� 9600  N 8 1

unsigned char RecvCount = 0;      //���ռ���                   
unsigned char SendCount = 0;      //���ͼ���
unsigned char RecvBuffer[16];     //���ջ���
unsigned char SendBuffer[16];     //���ͻ���

//*******************************************************************//
//                          ϵͳ��ʼ��
//*******************************************************************//
void System_Init(void)
{
	OSCCON = 0b01101000;            //�ڲ�4MHz 
	OSCTUNE= 0b00000000;            //����У׼
	ADCON1 = 0b10110000;            //�ڲ�Frc Vref = VDD
	ADCON0 = 0b00010001;            //ADON = 1 As AN4
    
	TRISA  = 0b00100000;            //RA0-RA3�����RA5����
	ANSELA = 0b00100000;            //RA5 ģ������  
	          
	TRISB  = 0b00001111;            //RB0-RB3��������
	ANSELB = 0b00001111;            //4����������
	WPUB   = 0b00000000;            //������
    
	IOCBP  = 0b00000000;            //�ص�ƽ�仯�ж�
	IOCBN  = 0b00000000;
	
	TRISD  = 0b00000000;            //PORTD���
	ANSELD = 0b00000000;            //����  I/O
    
	TRISC  = 0b10011000;            //���� I2C
    
	TRISE  = 0b00000000;            //PORTE���
	ANSELE = 0b00000000;            //����  I/O
	WPUE   = 0b00000000;            //������ 
	
	LATA  = 0x00;
	LATB  = 0x00;
	LATC  = 0x00;
	LATD  = 0x00;
	LATE  = 0x00;
}
	

//*******************************************************************//
//                    TMR0��ʱ��ʼ��
//*******************************************************************//
void TMR0_Init(void)
{
	OPTION_REG = 0b11010011;
	
	TMR0IF = 0;
	TMR0IE = 1;
}

	
//*******************************************************************//
//                    ��ʱ���ж�,��ʱ��������
//*******************************************************************//  

static void interrupt SystemISR(void)      //ϵͳ�ж�
{
	if(TMR0IE && TMR0IF)                   //4MHz  2.5ms
	{
		TMR0IF = 0;
		TMR0 = 0x65;
		CLRWDT();
	}
	if( RCIF & RCIE )
	{
		if (FERR)                         //������������
		{
			RecvBuffer[RecvCount] = RCREG;
			SPEN = 0;
			SPEN = 1;
		}
		RecvBuffer[RecvCount] = RCREG;   //��ȷ��������
		RecvCount = (RecvCount + 1) & 0x0F;
		LATA0 = ~LATA0;                  //��תDS1
		TXIE = 1;
		if (OERR)                        //�����������
		{
			RecvBuffer[RecvCount] = RCREG;
			RecvCount = (RecvCount + 1) & 0x0F;
			TXIE = 0;
			CREN = 0;
			CREN = 1;
		}
	}
	if (TXIF&TXIE)
	{  
		SendBuffer[SendCount] = RecvBuffer[SendCount];
		if ( SendCount != RecvCount)
		{
			TXREG = SendBuffer[SendCount];       //���ͽ��յ�������
			SendCount = (SendCount + 1) & 0x0F;
			LATA3 = ~LATA3;                      //��תDS3
		}
		else
		{ 
			if (TRMT)
			{  
				TXIE = 0;
			}
		}
	}
}
		

void RS232_Init(void)            //Init For Modbus
{
	unsigned char BaudRate = 0;
	BaudRate = BAUDRATE;
	switch(BaudRate)
	{
		case 1: 
				BRGH = 0;               //2400
				SPBRG = 25;
				break;
		case 2: 
				BRGH = 0;               //4800 
				SPBRG = 12;
				break;
		case 3: 
				BRGH = 1;               //9600
				SPBRG = 25;
				break;
		case 4: 
				BRGH = 1;               //19200
				SPBRG = 12;
				break;
	}
	SYNC = 0;	      // asynchronous
	SPEN = 1;	      // enable serial port pins
	CREN = 1;	      // enable reception
	TXEN = 1;         // enable Send
	SREN = 0;	      // no effect
	TXIE = 0;         // Disable TX interrupts
	RCIE = 1;         // Enable  RX interrupts
}


//*******************************************************************//
//                             �����򲿷�
//*******************************************************************//

void main(void)
{
	__delay_ms(100);
	System_Init();          //ϵͳ��ʼ��
	CLRWDT();               //WDT���Ź�
	TMR0_Init();            //TMR0��ʼ��
	RS232_Init();           //UART��ʼ��
	PEIE = 1;               //�����ж�����
	GIE = 1;                //���ж�����
	while (1)
	{
		NOP();
	}
}

